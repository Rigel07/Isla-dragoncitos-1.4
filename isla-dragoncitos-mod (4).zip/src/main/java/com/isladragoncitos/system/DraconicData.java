package com.isladragoncitos.system;

import com.isladragoncitos.IslaDragoncitosMod;
import com.isladragoncitos.entity.AncientDragonEntity;
import com.isladragoncitos.item.DragonCompassItem;
import com.isladragoncitos.worldgen.RiderLore;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.advancements.Advancement;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.levelgen.structure.StructureStart;

/**
 * Datos draconianos del jugador (puntos, islas descubiertas, marca del jinete, dragon activo) y la
 * logica de vida compartida. Se guardan en los datos persistentes del jugador, que sobreviven a la muerte.
 */
public final class DraconicData {
    public static final UUID SHARED_UUID = UUID.fromString("5d6c0888-9356-470f-8988-7cb74c2ac169");
    public static final String SHARED_PREFIX = "isladragoncitos_shared_";

    private static final String ROOT = "PlayerPersisted";
    private static final String KEY = "isladragoncitos";

    private static boolean linking;

    private DraconicData() {}

    private static CompoundTag data(Player player) {
        CompoundTag forge = player.getPersistentData();
        if (!forge.contains(ROOT)) {
            forge.put(ROOT, new CompoundTag());
        }
        CompoundTag persisted = forge.getCompound(ROOT);
        if (!persisted.contains(KEY)) {
            persisted.put(KEY, new CompoundTag());
        }
        return persisted.getCompound(KEY);
    }

    // ---------------------------------------------------------------- puntos

    /** Puntos draconianos en medios puntos (para poder gastar 0,5 por nivel). */
    public static int getHalfPoints(Player player) {
        return data(player).getInt("HalfPoints");
    }

    public static void addHalfPoints(Player player, int amount) {
        CompoundTag tag = data(player);
        tag.putInt("HalfPoints", Math.max(0, tag.getInt("HalfPoints") + amount));
    }

    public static String formatPoints(int halfPoints) {
        return halfPoints % 2 == 0 ? String.valueOf(halfPoints / 2) : (halfPoints / 2) + ",5";
    }

    public static boolean hasMark(Player player) {
        return data(player).getBoolean("Mark");
    }

    public static int islandsFound(Player player) {
        return data(player).getLongArray("Islands").length;
    }

    // ---------------------------------------------------------- dragon activo

    public static void setActiveDragon(Player player, AncientDragonEntity dragon) {
        data(player).putUUID("Dragon", dragon.getUUID());
    }

    @Nullable
    public static AncientDragonEntity findDragon(ServerPlayer player) {
        CompoundTag tag = data(player);
        if (!tag.hasUUID("Dragon")) {
            return null;
        }
        UUID id = tag.getUUID("Dragon");
        for (ServerLevel level : player.server.getAllLevels()) {
            Entity entity = level.getEntity(id);
            if (entity instanceof AncientDragonEntity dragon && dragon.isAlive()) {
                return dragon;
            }
        }
        return null;
    }

    // ---------------------------------------------------------------- logros

    public static void grant(ServerPlayer player, String id) {
        Advancement advancement = player.server.getAdvancements().getAdvancement(new ResourceLocation(IslaDragoncitosMod.MODID, id));
        if (advancement != null) {
            player.getAdvancements().award(advancement, "done");
        }
    }

    // ------------------------------------------------------------- eventos

    public static void onHatch(ServerPlayer player, UUID dragonId, int type) {
        CompoundTag tag = data(player);
        int mask = tag.getInt("Hatched") | (1 << type);
        tag.putInt("Hatched", mask);
        grant(player, "hatch");
        grant(player, type == 0 ? "hatch_fire" : (type == 1 ? "hatch_ice" : (type == 2 ? "hatch_storm" : "hatch_water")));
        if (mask == 15) {
            grant(player, "all_elements");
        }
        if (!tag.getBoolean("Mark")) {
            tag.putBoolean("Mark", true);
            tag.putUUID("MarkDragon", dragonId);
            grant(player, "rider_mark");
            player.displayClientMessage(Component.literal("§6§lMarca del Jinete§r §eha despertado en ti: todas tus ventajas (actuales y futuras) se duplican mientras tu dragón siga vivo."), false);
            ServerLevel level = player.serverLevel();
            level.sendParticles(ParticleTypes.TOTEM_OF_UNDYING, player.getX(), player.getY() + 1.0D, player.getZ(),
                    60, 0.6D, 1.0D, 0.6D, 0.4D);
        }
    }

    public static void onDragonDied(AncientDragonEntity dragon) {
        if (!(dragon.getOwner() instanceof ServerPlayer owner)) {
            return;
        }
        CompoundTag tag = data(owner);
        if (tag.hasUUID("Dragon") && tag.getUUID("Dragon").equals(dragon.getUUID())) {
            tag.remove("Dragon");
        }
        // la Marca del Jinete dura mientras viva el dragon que la desperto
        if (tag.getBoolean("Mark") && (!tag.hasUUID("MarkDragon") || tag.getUUID("MarkDragon").equals(dragon.getUUID()))) {
            tag.remove("Mark");
            tag.remove("MarkDragon");
            owner.displayClientMessage(Component.literal("§7La Marca del Jinete se ha desvanecido con tu dragón."), false);
        }
        if (dragon.hasSharedLife() && owner.isAlive() && !linking) {
            linking = true;
            try {
                owner.displayClientMessage(Component.literal("Tu dragón ha muerto y su vida estaba unida a la tuya."), false);
                owner.kill();
            } finally {
                linking = false;
            }
        } else {
            owner.displayClientMessage(Component.literal("Tu dragón ha muerto."), false);
        }
    }

    /** Cuando muere el jugador, el dragon con vida compartida muere con el (definitivamente). */
    public static void onPlayerDied(ServerPlayer player) {
        if (linking) {
            return;
        }
        AncientDragonEntity dragon = findDragon(player);
        if (dragon != null && dragon.hasSharedLife()) {
            linking = true;
            try {
                dragon.kill();
            } finally {
                linking = false;
            }
        }
    }

    // ---------------------------------------------------------------- tick

    public static void tickPlayer(ServerPlayer player) {
        if (player.tickCount % 40 == 0) {
            discover(player);
            ruinsAndLore(player);
        }
        if (player.tickCount % 10 == 0) {
            sharedLife(player);
        }
    }

    /** Detecta ruinas de los jinetes cerca y los capitulos de la cronica que el jugador lleva encima. */
    private static void ruinsAndLore(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        StructureStart start = level.structureManager().getStructureWithPieceAt(player.blockPosition(), RiderLore.RUINS);
        if (start.isValid()) {
            grant(player, "ruins_found");
        }
        CompoundTag tag = data(player);
        int mask = tag.getInt("Lore");
        int before = mask;
        for (net.minecraft.world.item.ItemStack stack : player.getInventory().items) {
            int chapter = RiderLore.chapterOf(stack);
            if (chapter >= 0) {
                mask |= 1 << chapter;
            }
        }
        for (net.minecraft.world.item.ItemStack stack : player.getInventory().offhand) {
            int chapter = RiderLore.chapterOf(stack);
            if (chapter >= 0) {
                mask |= 1 << chapter;
            }
        }
        if (mask != before) {
            tag.putInt("Lore", mask);
        }
        if (mask != 0) {
            grant(player, "lore_first");
        }
        if (mask == (1 << RiderLore.chapters()) - 1) {
            grant(player, "chronicler");
        }
    }

    private static void discover(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        StructureStart start = level.structureManager().getStructureWithPieceAt(player.blockPosition(), DragonCompassItem.ISLANDS);
        if (!start.isValid()) {
            return;
        }
        BlockPos center = start.getBoundingBox().getCenter();
        long key = new BlockPos(center.getX(), 0, center.getZ()).asLong();
        CompoundTag tag = data(player);
        long[] known = tag.getLongArray("Islands");
        for (long l : known) {
            if (l == key) {
                return;
            }
        }
        long[] updated = new long[known.length + 1];
        System.arraycopy(known, 0, updated, 0, known.length);
        updated[known.length] = key;
        tag.putLongArray("Islands", updated);
        int gained = hasMark(player) ? 40 : 20;
        addHalfPoints(player, gained);
        player.displayClientMessage(Component.literal("§d¡Isla de dragoncitos descubierta! §f+" + (gained / 2)
                + " puntos draconianos §7(" + formatPoints(getHalfPoints(player)) + " en total)"), false);
        grant(player, "island_found");
        if (updated.length >= 10) {
            grant(player, "islands_10");
        }
        if (updated.length >= 50) {
            grant(player, "islands_50");
        }
    }

    private static void sharedLife(ServerPlayer player) {
        AttributeInstance maxHp = player.getAttribute(Attributes.MAX_HEALTH);
        if (maxHp == null) {
            return;
        }
        AttributeModifier existing = maxHp.getModifier(SHARED_UUID);
        AncientDragonEntity dragon = findDragon(player);
        if (dragon != null && dragon.hasSharedLife() && dragon.level() == player.level() && player.isAlive()) {
            double bonus = dragon.getMaxHealth();
            String name = SHARED_PREFIX + dragon.getDragonType();
            if (existing == null || existing.getAmount() != bonus || !existing.getName().equals(name)) {
                maxHp.removeModifier(SHARED_UUID);
                maxHp.addPermanentModifier(new AttributeModifier(SHARED_UUID, name, bonus, AttributeModifier.Operation.ADDITION));
                if (existing == null) {
                    player.setHealth(player.getMaxHealth());
                } else if (bonus > existing.getAmount()) {
                    player.heal((float) (bonus - existing.getAmount()));
                }
            }
            dragon.setHealth(Math.max(1.0F, Math.min(dragon.getMaxHealth(), player.getHealth())));
            if (player.tickCount - player.getLastHurtByMobTimestamp() > 200 && player.getHealth() < player.getMaxHealth()) {
                player.heal(player.getMaxHealth() * 0.003F);
            }
        } else if (existing != null) {
            maxHp.removeModifier(SHARED_UUID);
            if (player.getHealth() > player.getMaxHealth()) {
                player.setHealth(player.getMaxHealth());
            }
        }
    }

    // ------------------------------------------------------------------ mejoras

    /** Gasta puntos en subir niveles. Devuelve un mensaje con el resultado. */
    public static String upgrade(ServerPlayer player, AncientDragonEntity dragon, String stat, int requested) {
        int cost;
        int current;
        int max;
        switch (stat) {
            case "fuerza" -> {
                cost = 2;
                current = dragon.getStrengthLvl();
                max = AncientDragonEntity.MAX_STRENGTH;
            }
            case "velocidad" -> {
                cost = 10;
                current = dragon.getSpeedLvl();
                max = AncientDragonEntity.MAX_SPEED;
            }
            case "vida" -> {
                cost = 1;
                current = dragon.getHealthLvl();
                max = AncientDragonEntity.MAX_HEALTH_LVL;
            }
            case "escamas" -> {
                cost = 2;
                current = dragon.getScales();
                max = AncientDragonEntity.MAX_SCALES;
            }
            case "vida_compartida" -> {
                cost = 200;
                current = dragon.hasSharedLife() ? 1 : 0;
                max = 1;
            }
            default -> {
                return "Mejora desconocida. Usa: fuerza, velocidad, vida, escamas o vida_compartida.";
            }
        }
        if (current >= max) {
            return stat.equals("escamas") ? "Tu dragón ya tiene todas las escamas." : "Esa mejora ya está al máximo.";
        }
        int levels = Math.min(requested, max - current);
        int half = getHalfPoints(player);
        int affordable = half / cost;
        if (affordable <= 0) {
            return "No tienes suficientes puntos draconianos (necesitas " + formatPoints(cost) + " por nivel; tienes "
                    + formatPoints(half) + ").";
        }
        levels = Math.min(levels, affordable);
        addHalfPoints(player, -levels * cost);
        switch (stat) {
            case "fuerza" -> dragon.setStrengthLvl(current + levels);
            case "velocidad" -> dragon.setSpeedLvl(current + levels);
            case "vida" -> {
                dragon.setHealthLvl(current + levels);
                dragon.heal(levels);
            }
            case "escamas" -> dragon.setScales(current + levels);
            default -> {
                dragon.setSharedLife(true);
                grant(player, "shared_life");
            }
        }
        return "Mejora aplicada: " + stat + " +" + levels + " (puntos restantes: " + formatPoints(getHalfPoints(player)) + ").";
    }
}
