package com.isladragoncitos.worldgen;

import com.isladragoncitos.registry.ModStructures;
import com.mojang.serialization.Codec;
import java.util.Optional;
import net.minecraft.util.RandomSource;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.QuartPos;
import net.minecraft.tags.BiomeTags;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.Biomes;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.WorldgenRandom;
import net.minecraft.world.level.levelgen.structure.Structure;
import net.minecraft.world.level.levelgen.structure.StructureType;

/**
 * Isla flotante. Busca un rio cercano para que la cascada caiga en el: si lo encuentra, la isla
 * se coloca justo encima; si no, solo aparece de vez en cuando (la cascada cae a un estanque).
 */
public class IslaStructure extends Structure {
    public static final Codec<IslaStructure> CODEC = simpleCodec(IslaStructure::new);

    /** Probabilidad (%) de que aparezca una isla aunque no haya ningun rio cerca. */
    private static final int NO_RIVER_CHANCE = 35;
    private static final int RIVER_SEARCH = 48;

    public IslaStructure(Structure.StructureSettings settings) {
        super(settings);
    }

    @Override
    public StructureType<?> type() {
        return ModStructures.ISLA_TYPE.get();
    }

    @Override
    protected Optional<Structure.GenerationStub> findGenerationPoint(Structure.GenerationContext context) {
        ChunkPos chunkPos = context.chunkPos();
        int mx = chunkPos.getMiddleBlockX();
        int mz = chunkPos.getMiddleBlockZ();
        WorldgenRandom random = context.random();

        long seed = random.nextLong();
        int radius = pickRadius(random);
        double fallAngle = random.nextDouble() * Math.PI * 2.0D;
        int styleId = pickStyle(context, mx, mz, random);
        IslaShape shape = new IslaShape(seed, radius, fallAngle, styleId, IslaPiece.CURRENT_VERSION);

        // las islas grandes buscan el rio mas cerca para que toda la estructura quede
        // dentro del alcance de referencias de chunks (8 chunks) de la estructura
        int search = Math.min(RIVER_SEARCH, 94 - 2 * shape.maxR);
        search -= search % 4;

        int cx;
        int cz;
        int[] river = search >= 8 ? findRiver(context, mx, mz, search) : null;
        if (river != null) {
            cx = river[0] - shape.fallX;
            cz = river[1] - shape.fallZ;
        } else {
            if (random.nextInt(100) >= (radius >= 37 ? 60 : NO_RIVER_CHANCE)) {
                return Optional.empty();
            }
            cx = mx;
            cz = mz;
        }

        int fx = cx + shape.fallX;
        int fz = cz + shape.fallZ;
        int vx = cx + shape.vineX;
        int vz = cz + shape.vineZ;

        int groundFall = height(context, fx, fz);
        int groundVine = height(context, vx, vz);
        int maxHeight = Math.max(groundFall, groundVine);
        maxHeight = Math.max(maxHeight, height(context, cx, cz));
        for (int i = 0; i < 12; i++) {
            double angle = i * Math.PI / 6.0D;
            int sx = cx + (int) Math.round(Math.cos(angle) * (radius * 0.85D));
            int sz = cz + (int) Math.round(Math.sin(angle) * (radius * 0.85D));
            maxHeight = Math.max(maxHeight, height(context, sx, sz));
        }

        int top = maxHeight + shape.depth + 24 + random.nextInt(10);
        int cap = context.heightAccessor().getMaxBuildHeight() - 40;
        if (top > cap) {
            top = cap;
        }
        if (top < groundFall + 25 || top < groundVine + 25) {
            return Optional.empty();
        }

        boolean overWater = isWater(context, fx, groundFall - 1, fz);
        IslaPiece piece = new IslaPiece(cx, cz, top, radius, seed, fallAngle, groundVine, groundFall, overWater, styleId);
        BlockPos start = new BlockPos(cx, groundFall, cz);
        return Optional.of(new Structure.GenerationStub(start, builder -> builder.addPiece(piece)));
    }

    private static int height(Structure.GenerationContext context, int x, int z) {
        return context.chunkGenerator().getBaseHeight(x, z, Heightmap.Types.WORLD_SURFACE_WG,
                context.heightAccessor(), context.randomState());
    }

    private static boolean isWater(Structure.GenerationContext context, int x, int y, int z) {
        return context.chunkGenerator()
                .getBaseColumn(x, z, context.heightAccessor(), context.randomState())
                .getBlock(y).is(Blocks.WATER);
    }

    /** Tamano muy variable: de islotes diminutos a islas gigantes. */
    private static int pickRadius(RandomSource random) {
        int roll = random.nextInt(100);
        if (roll < 12) {
            return 11 + random.nextInt(4);
        }
        if (roll < 33) {
            return 15 + random.nextInt(6);
        }
        if (roll < 62) {
            return 21 + random.nextInt(7);
        }
        if (roll < 82) {
            return 28 + random.nextInt(9);
        }
        if (roll < 94) {
            return 37 + random.nextInt(10);
        }
        return 52 + random.nextInt(13);
    }

    /** El bioma del lugar favorece un tipo de isla, pero cualquiera puede aparecer en cualquier sitio. */
    private static int pickStyle(Structure.GenerationContext context, int mx, int mz, RandomSource random) {
        Holder<Biome> biome = context.biomeSource().getNoiseBiome(
                QuartPos.fromBlock(mx), QuartPos.fromBlock(64), QuartPos.fromBlock(mz),
                context.randomState().sampler());
        int favored = -1;
        if (biome.is(BiomeTags.IS_JUNGLE)) {
            favored = IslaStyle.JUNGLA;
        } else if (biome.is(BiomeTags.IS_BADLANDS) || biome.is(Biomes.DESERT)) {
            favored = IslaStyle.OASIS;
        } else if (biome.value().getBaseTemperature() <= 0.15F) {
            favored = IslaStyle.NIEVE;
        }
        if (favored >= 0 && random.nextInt(100) < 55) {
            return favored;
        }
        int[] weights = {30, 10, 15, 15, 10, 10};
        int roll = random.nextInt(90);
        for (int i = 0; i < weights.length; i++) {
            roll -= weights[i];
            if (roll < 0) {
                return i;
            }
        }
        return IslaStyle.PRIMAVERA;
    }

    /** Punto de agua de un rio cercano (el mas proximo al centro del chunk), o null si no hay. */
    private static int[] findRiver(Structure.GenerationContext context, int mx, int mz, int search) {
        int bestDistance = Integer.MAX_VALUE;
        int bx = 0;
        int bz = 0;
        boolean found = false;
        for (int dx = -search; dx <= search; dx += 4) {
            for (int dz = -search; dz <= search; dz += 4) {
                int d = dx * dx + dz * dz;
                if (d >= bestDistance) {
                    continue;
                }
                Holder<Biome> biome = context.biomeSource().getNoiseBiome(
                        QuartPos.fromBlock(mx + dx), QuartPos.fromBlock(63), QuartPos.fromBlock(mz + dz),
                        context.randomState().sampler());
                if (biome.is(BiomeTags.IS_RIVER)) {
                    bestDistance = d;
                    bx = mx + dx;
                    bz = mz + dz;
                    found = true;
                }
            }
        }
        if (!found) {
            return null;
        }

        // afina hasta una columna que realmente tenga agua
        int seaY = context.chunkGenerator().getSeaLevel() - 1;
        int bestWater = Integer.MAX_VALUE;
        int wx = bx;
        int wz = bz;
        for (int dx = -8; dx <= 8; dx += 2) {
            for (int dz = -8; dz <= 8; dz += 2) {
                int d = dx * dx + dz * dz;
                if (d < bestWater && isWater(context, bx + dx, seaY, bz + dz)) {
                    bestWater = d;
                    wx = bx + dx;
                    wz = bz + dz;
                }
            }
        }
        return new int[]{wx, wz};
    }
}
