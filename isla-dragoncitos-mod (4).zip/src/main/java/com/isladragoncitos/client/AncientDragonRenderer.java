package com.isladragoncitos.client;

import com.isladragoncitos.IslaDragoncitosMod;
import com.isladragoncitos.entity.AncientDragonEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;

public class AncientDragonRenderer extends MobRenderer<AncientDragonEntity, AncientDragonModel> {
    private static final String[] NAMES = {"fire", "ice", "storm", "water"};

    public AncientDragonRenderer(EntityRendererProvider.Context context) {
        super(context, new AncientDragonModel(context.bakeLayer(AncientDragonModel.LAYER_LOCATION)), 1.0F);
        this.addLayer(new GlowLayer(this));
    }

    private static ResourceLocation texture(int type, boolean glow) {
        return new ResourceLocation(IslaDragoncitosMod.MODID,
                "textures/entity/ancient_dragon_" + NAMES[Math.max(0, Math.min(3, type))] + (glow ? "_glow" : "") + ".png");
    }

    @Override
    public ResourceLocation getTextureLocation(AncientDragonEntity entity) {
        return texture(entity.getDragonType(), false);
    }

    @Override
    protected void scale(AncientDragonEntity entity, PoseStack poseStack, float partialTick) {
        float scale = entity.getVisualScale();
        poseStack.scale(scale, scale, scale);
        this.shadowRadius = 0.9F * scale;
    }

    /** Ojos que brillan en la oscuridad. */
    private static final class GlowLayer extends RenderLayer<AncientDragonEntity, AncientDragonModel> {
        GlowLayer(AncientDragonRenderer renderer) {
            super(renderer);
        }

        @Override
        public void render(PoseStack poseStack, MultiBufferSource buffer, int packedLight, AncientDragonEntity entity,
                           float limbSwing, float limbSwingAmount, float partialTick, float ageInTicks,
                           float netHeadYaw, float headPitch) {
            VertexConsumer consumer = buffer.getBuffer(RenderType.eyes(texture(entity.getDragonType(), true)));
            this.getParentModel().renderToBuffer(poseStack, consumer, 15728640, OverlayTexture.NO_OVERLAY, 1.0F, 1.0F, 1.0F, 1.0F);
        }
    }
}
