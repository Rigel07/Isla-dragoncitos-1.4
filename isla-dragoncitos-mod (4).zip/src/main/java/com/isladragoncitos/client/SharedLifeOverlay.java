package com.isladragoncitos.client;

import com.isladragoncitos.IslaDragoncitosMod;
import com.isladragoncitos.system.DraconicData;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Con vida compartida, la barra de corazones se sustituye por un unico corazon grande, centrado, entre la armadura y la
 * barra de experiencia: del color de tu dragon, con borde dorado y la vida que os queda a los dos dentro.
 */
@Mod.EventBusSubscriber(modid = IslaDragoncitosMod.MODID, value = Dist.CLIENT)
public final class SharedLifeOverlay {
    private static final String[] HEART = {
            "..XXX...XXX..",
            ".XXXXX.XXXXX.",
            "XXXXXXXXXXXXX",
            "XXXXXXXXXXXXX",
            "XXXXXXXXXXXXX",
            "XXXXXXXXXXXXX",
            ".XXXXXXXXXXX.",
            "..XXXXXXXXX..",
            "...XXXXXXX...",
            "....XXXXX....",
            ".....XXX.....",
            "......X......"
    };
    private static final int[] COLORS = {0xFFE8402A, 0xFF4FC3FF, 0xFFE6E03A, 0xFF2EE6C8};
    private static final int[] SHADES = {0xFFA82414, 0xFF2A86C4, 0xFFB8B21E, 0xFF139C88};
    private static final int GOLD = 0xFFFFD34D;
    private static final int CELL = 2;

    private SharedLifeOverlay() {}

    private static boolean filled(int row, int col) {
        return row >= 0 && row < HEART.length && col >= 0 && col < HEART[row].length() && HEART[row].charAt(col) == 'X';
    }

    @SubscribeEvent
    public static void onOverlay(RenderGuiOverlayEvent.Pre event) {
        if (event.getOverlay() != VanillaGuiOverlay.PLAYER_HEALTH.type()) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player == null) {
            return;
        }
        AttributeInstance maxHealth = player.getAttribute(Attributes.MAX_HEALTH);
        AttributeModifier modifier = maxHealth == null ? null : maxHealth.getModifier(DraconicData.SHARED_UUID);
        if (modifier == null) {
            return;
        }
        event.setCanceled(true);
        int type = 0;
        String name = modifier.getName();
        if (name.startsWith(DraconicData.SHARED_PREFIX)) {
            try {
                type = Integer.parseInt(name.substring(DraconicData.SHARED_PREFIX.length()));
            } catch (NumberFormatException ignored) {
                type = 0;
            }
        }
        type = Math.max(0, Math.min(3, type));
        GuiGraphics graphics = event.getGuiGraphics();
        int width = HEART[0].length() * CELL;
        int height = HEART.length * CELL;
        int x = event.getWindow().getGuiScaledWidth() / 2 - width / 2;
        int y = event.getWindow().getGuiScaledHeight() - 32 - height;

        // borde dorado
        for (int row = -1; row <= HEART.length; row++) {
            for (int col = -1; col <= HEART[0].length(); col++) {
                if (filled(row, col)) {
                    continue;
                }
                boolean next = false;
                for (int dr = -1; dr <= 1 && !next; dr++) {
                    for (int dc = -1; dc <= 1; dc++) {
                        if (filled(row + dr, col + dc)) {
                            next = true;
                            break;
                        }
                    }
                }
                if (next) {
                    graphics.fill(x + col * CELL, y + row * CELL, x + col * CELL + CELL, y + row * CELL + CELL, GOLD);
                }
            }
        }
        // relleno con degradado y brillo
        for (int row = 0; row < HEART.length; row++) {
            for (int col = 0; col < HEART[row].length(); col++) {
                if (!filled(row, col)) {
                    continue;
                }
                boolean shine = row >= 1 && row <= 3 && col >= 1 && col <= 3 && (row + col) % 2 == 0;
                int color = shine ? 0xFFFFFFFF : (row > 7 ? SHADES[type] : COLORS[type]);
                graphics.fill(x + col * CELL, y + row * CELL, x + col * CELL + CELL, y + row * CELL + CELL, color);
            }
        }
        String text = String.valueOf((int) Math.ceil(player.getHealth()));
        float scale = text.length() >= 4 ? 0.6F : (text.length() == 3 ? 0.75F : 1.0F);
        graphics.pose().pushPose();
        graphics.pose().translate(x + width / 2.0F, y + height * 0.38F, 0.0F);
        graphics.pose().scale(scale, scale, 1.0F);
        graphics.drawString(mc.font, text, -mc.font.width(text) / 2, -4, 0xFFFFFF, true);
        graphics.pose().popPose();
    }
}
