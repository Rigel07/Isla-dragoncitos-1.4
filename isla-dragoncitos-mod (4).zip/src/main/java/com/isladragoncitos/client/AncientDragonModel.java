package com.isladragoncitos.client;

import com.isladragoncitos.IslaDragoncitosMod;
import com.isladragoncitos.entity.AncientDragonEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/** Modelo del dragon antiguo (generado a partir de una descripcion de piezas; textura 256x256). */
public class AncientDragonModel extends EntityModel<AncientDragonEntity> {
    public static final ModelLayerLocation LAYER_LOCATION =
            new ModelLayerLocation(new ResourceLocation(IslaDragoncitosMod.MODID, "ancient_dragon"), "main");

    private final ModelPart root;
    private final ModelPart body;
    private final ModelPart saddle;
    private final ModelPart neck1;
    private final ModelPart neck2;
    private final ModelPart neck3;
    private final ModelPart head;
    private final ModelPart jaw;
    private final ModelPart hornR;
    private final ModelPart hornL;
    private final ModelPart tail1;
    private final ModelPart tail2;
    private final ModelPart tail3;
    private final ModelPart tail4;
    private final ModelPart tail5;
    private final ModelPart tail6;
    private final ModelPart wingArmR;
    private final ModelPart wingForeR;
    private final ModelPart wingTipR;
    private final ModelPart wingArmL;
    private final ModelPart wingForeL;
    private final ModelPart wingTipL;
    private final ModelPart legFR;
    private final ModelPart legFRLo;
    private final ModelPart legFRFt;
    private final ModelPart legFL;
    private final ModelPart legFLLo;
    private final ModelPart legFLFt;
    private final ModelPart legBR;
    private final ModelPart legBRLo;
    private final ModelPart legBRFt;
    private final ModelPart legBL;
    private final ModelPart legBLLo;
    private final ModelPart legBLFt;

    public AncientDragonModel(ModelPart root) {
        this.root = root;
        this.body = root.getChild("body");
        this.saddle = root.getChild("body").getChild("saddle");
        this.neck1 = root.getChild("body").getChild("neck1");
        this.neck2 = root.getChild("body").getChild("neck1").getChild("neck2");
        this.neck3 = root.getChild("body").getChild("neck1").getChild("neck2").getChild("neck3");
        this.head = root.getChild("body").getChild("neck1").getChild("neck2").getChild("neck3").getChild("head");
        this.jaw = root.getChild("body").getChild("neck1").getChild("neck2").getChild("neck3").getChild("head").getChild("jaw");
        this.hornR = root.getChild("body").getChild("neck1").getChild("neck2").getChild("neck3").getChild("head").getChild("hornR");
        this.hornL = root.getChild("body").getChild("neck1").getChild("neck2").getChild("neck3").getChild("head").getChild("hornL");
        this.tail1 = root.getChild("body").getChild("tail1");
        this.tail2 = root.getChild("body").getChild("tail1").getChild("tail2");
        this.tail3 = root.getChild("body").getChild("tail1").getChild("tail2").getChild("tail3");
        this.tail4 = root.getChild("body").getChild("tail1").getChild("tail2").getChild("tail3").getChild("tail4");
        this.tail5 = root.getChild("body").getChild("tail1").getChild("tail2").getChild("tail3").getChild("tail4").getChild("tail5");
        this.tail6 = root.getChild("body").getChild("tail1").getChild("tail2").getChild("tail3").getChild("tail4").getChild("tail5").getChild("tail6");
        this.wingArmR = root.getChild("body").getChild("wingArmR");
        this.wingForeR = root.getChild("body").getChild("wingArmR").getChild("wingForeR");
        this.wingTipR = root.getChild("body").getChild("wingArmR").getChild("wingForeR").getChild("wingTipR");
        this.wingArmL = root.getChild("body").getChild("wingArmL");
        this.wingForeL = root.getChild("body").getChild("wingArmL").getChild("wingForeL");
        this.wingTipL = root.getChild("body").getChild("wingArmL").getChild("wingForeL").getChild("wingTipL");
        this.legFR = root.getChild("body").getChild("legFR");
        this.legFRLo = root.getChild("body").getChild("legFR").getChild("legFRLo");
        this.legFRFt = root.getChild("body").getChild("legFR").getChild("legFRLo").getChild("legFRFt");
        this.legFL = root.getChild("body").getChild("legFL");
        this.legFLLo = root.getChild("body").getChild("legFL").getChild("legFLLo");
        this.legFLFt = root.getChild("body").getChild("legFL").getChild("legFLLo").getChild("legFLFt");
        this.legBR = root.getChild("body").getChild("legBR");
        this.legBRLo = root.getChild("body").getChild("legBR").getChild("legBRLo");
        this.legBRFt = root.getChild("body").getChild("legBR").getChild("legBRLo").getChild("legBRFt");
        this.legBL = root.getChild("body").getChild("legBL");
        this.legBLLo = root.getChild("body").getChild("legBL").getChild("legBLLo");
        this.legBLFt = root.getChild("body").getChild("legBL").getChild("legBLLo").getChild("legBLFt");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition d_body = root.addOrReplaceChild("body", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-7F, -6F, -14F, 14F, 12F, 28F, new CubeDeformation(0F))
                .texOffs(77, 41).addBox(-8F, -7F, -15F, 16F, 13F, 10F, new CubeDeformation(0.2F))
                .texOffs(85, 0).addBox(-5F, 6F, -13F, 10F, 1F, 24F, new CubeDeformation(0F))
                .texOffs(108, 122).addBox(-1F, -9F, -12F, 2F, 4F, 2F, new CubeDeformation(0F))
                .texOffs(99, 122).addBox(-1F, -9F, -8F, 2F, 4F, 2F, new CubeDeformation(0F))
                .texOffs(90, 122).addBox(-1F, -9F, 8F, 2F, 4F, 2F, new CubeDeformation(0F))
                .texOffs(81, 122).addBox(-1F, -9F, 12F, 2F, 4F, 2F, new CubeDeformation(0F)),
                PartPose.offsetAndRotation(0F, 10F, 0F, 0F, 0F, 0F));
        PartDefinition d_saddle = d_body.addOrReplaceChild("saddle", CubeListBuilder.create()
                .texOffs(81, 83).addBox(-4F, -8F, -6F, 8F, 2F, 12F, new CubeDeformation(0F))
                .texOffs(56, 83).addBox(-6F, -7F, -5F, 2F, 5F, 10F, new CubeDeformation(0F))
                .texOffs(31, 83).addBox(4F, -7F, -5F, 2F, 5F, 10F, new CubeDeformation(0F))
                .texOffs(122, 65).addBox(-7.4F, -6.4F, -1.5F, 14.8F, 12.8F, 3F, new CubeDeformation(0F))
                .texOffs(134, 122).addBox(-1.5F, -10F, -7F, 3F, 3F, 2F, new CubeDeformation(0F))
                .texOffs(117, 122).addBox(-3F, -10F, 5F, 6F, 3F, 2F, new CubeDeformation(0F))
                .texOffs(15, 135).addBox(-6.2F, -6F, -3F, 1F, 1F, 1F, new CubeDeformation(0F))
                .texOffs(10, 135).addBox(5.2F, -6F, -3F, 1F, 1F, 1F, new CubeDeformation(0F))
                .texOffs(5, 135).addBox(-6.2F, -6F, 2F, 1F, 1F, 1F, new CubeDeformation(0F))
                .texOffs(0, 135).addBox(5.2F, -6F, 2F, 1F, 1F, 1F, new CubeDeformation(0F)),
                PartPose.offsetAndRotation(0F, 0F, 0F, 0F, 0F, 0F));
        PartDefinition d_neck1 = d_body.addOrReplaceChild("neck1", CubeListBuilder.create()
                .texOffs(194, 65).addBox(-3.5F, -3.5F, -8F, 7F, 7F, 8F, new CubeDeformation(0F))
                .texOffs(0, 129).addBox(-1F, -6F, -6F, 2F, 3F, 2F, new CubeDeformation(0F)),
                PartPose.offsetAndRotation(0F, -2F, -13F, -0.55F, 0F, 0F));
        PartDefinition d_neck2 = d_neck1.addOrReplaceChild("neck2", CubeListBuilder.create()
                .texOffs(153, 83).addBox(-3F, -3F, -8F, 6F, 6F, 8F, new CubeDeformation(0F))
                .texOffs(243, 122).addBox(-1F, -5.5F, -5F, 2F, 3F, 2F, new CubeDeformation(0F)),
                PartPose.offsetAndRotation(0F, 0F, -7F, 0.15F, 0F, 0F));
        PartDefinition d_neck3 = d_neck2.addOrReplaceChild("neck3", CubeListBuilder.create()
                .texOffs(211, 83).addBox(-3F, -3F, -7F, 6F, 6F, 7F, new CubeDeformation(0F))
                .texOffs(234, 122).addBox(-1F, -5.5F, -4F, 2F, 3F, 2F, new CubeDeformation(0F)),
                PartPose.offsetAndRotation(0F, 0F, -7F, 0.25F, 0F, 0F));
        PartDefinition d_head = d_neck3.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(159, 65).addBox(-4.5F, -4F, -8F, 9F, 8F, 8F, new CubeDeformation(0F))
                .texOffs(131, 99).addBox(-3F, -1.5F, -15F, 6F, 4F, 7F, new CubeDeformation(0F))
                .texOffs(149, 129).addBox(2.2F, -3F, -9F, 2F, 1.5F, 1.2F, new CubeDeformation(0F))
                .texOffs(141, 129).addBox(-4.2F, -3F, -9F, 2F, 1.5F, 1.2F, new CubeDeformation(0F))
                .texOffs(178, 122).addBox(-5.5F, -5F, -4F, 2F, 2F, 3F, new CubeDeformation(0F))
                .texOffs(167, 122).addBox(3.5F, -5F, -4F, 2F, 2F, 3F, new CubeDeformation(0F))
                .texOffs(156, 122).addBox(-1F, -6F, -6F, 2F, 2F, 3F, new CubeDeformation(0F))
                .texOffs(145, 122).addBox(-1F, -5F, -2F, 2F, 2F, 3F, new CubeDeformation(0F)),
                PartPose.offsetAndRotation(0F, 0F, -6F, 0.35F, 0F, 0F));
        PartDefinition d_jaw = d_head.addOrReplaceChild("jaw", CubeListBuilder.create()
                .texOffs(116, 112).addBox(-2.5F, 0F, -7F, 5F, 2F, 7F, new CubeDeformation(0F))
                .texOffs(25, 135).addBox(-2.5F, -1F, -7F, 1F, 1F, 1F, new CubeDeformation(0F))
                .texOffs(20, 135).addBox(1.5F, -1F, -7F, 1F, 1F, 1F, new CubeDeformation(0F)),
                PartPose.offsetAndRotation(0F, 2.5F, -8F, 0.05F, 0F, 0F));
        PartDefinition d_hornR = d_head.addOrReplaceChild("hornR", CubeListBuilder.create()
                .texOffs(81, 99).addBox(-1F, -1F, 0F, 2F, 2F, 10F, new CubeDeformation(0F)),
                PartPose.offsetAndRotation(3.2F, -3.5F, -3F, 0.55F, 0.4F, 0F));
        PartDefinition d_hornL = d_head.addOrReplaceChild("hornL", CubeListBuilder.create()
                .texOffs(106, 99).addBox(-1F, -1F, 0F, 2F, 2F, 10F, new CubeDeformation(0F)),
                PartPose.offsetAndRotation(-3.2F, -3.5F, -3F, 0.55F, -0.4F, 0F));
        PartDefinition d_tail1 = d_body.addOrReplaceChild("tail1", CubeListBuilder.create()
                .texOffs(122, 83).addBox(-3.5F, -3F, 0F, 7F, 6F, 8F, new CubeDeformation(0F))
                .texOffs(225, 122).addBox(-0.5F, -5F, 2F, 1F, 2F, 3F, new CubeDeformation(0F)),
                PartPose.offsetAndRotation(0F, -1F, 13F, -0.05F, 0F, 0F));
        PartDefinition d_tail2 = d_tail1.addOrReplaceChild("tail2", CubeListBuilder.create()
                .texOffs(182, 83).addBox(-3F, -2.5F, 0F, 6F, 5F, 8F, new CubeDeformation(0F))
                .texOffs(216, 122).addBox(-0.5F, -4.5F, 2F, 1F, 2F, 3F, new CubeDeformation(0F)),
                PartPose.offsetAndRotation(0F, 0F, 7.5F, 0F, 0F, 0F));
        PartDefinition d_tail3 = d_tail2.addOrReplaceChild("tail3", CubeListBuilder.create()
                .texOffs(0, 99).addBox(-2.5F, -2F, 0F, 5F, 4F, 8F, new CubeDeformation(0F))
                .texOffs(207, 122).addBox(-0.5F, -4F, 2F, 1F, 2F, 3F, new CubeDeformation(0F)),
                PartPose.offsetAndRotation(0F, 0F, 7.5F, 0F, 0F, 0F));
        PartDefinition d_tail4 = d_tail3.addOrReplaceChild("tail4", CubeListBuilder.create()
                .texOffs(158, 99).addBox(-2F, -1.5F, 0F, 4F, 3F, 8F, new CubeDeformation(0F))
                .texOffs(198, 122).addBox(-0.5F, -3.5F, 2F, 1F, 2F, 3F, new CubeDeformation(0F)),
                PartPose.offsetAndRotation(0F, 0F, 7.5F, 0F, 0F, 0F));
        PartDefinition d_tail5 = d_tail4.addOrReplaceChild("tail5", CubeListBuilder.create()
                .texOffs(183, 99).addBox(-1.5F, -1F, 0F, 3F, 2F, 8F, new CubeDeformation(0F))
                .texOffs(189, 122).addBox(-0.5F, -3F, 2F, 1F, 2F, 3F, new CubeDeformation(0F)),
                PartPose.offsetAndRotation(0F, 0F, 7.5F, 0F, 0F, 0F));
        PartDefinition d_tail6 = d_tail5.addOrReplaceChild("tail6", CubeListBuilder.create()
                .texOffs(225, 112).addBox(-1F, -1F, 0F, 2F, 2F, 6F, new CubeDeformation(0F))
                .texOffs(206, 99).addBox(-4F, -0.5F, 3F, 8F, 1F, 8F, new CubeDeformation(0F))
                .texOffs(70, 122).addBox(-1F, -4F, 2F, 2F, 3F, 3F, new CubeDeformation(0F)),
                PartPose.offsetAndRotation(0F, 0F, 7.5F, 0F, 0F, 0F));
        PartDefinition d_wingArmR = d_body.addOrReplaceChild("wingArmR", CubeListBuilder.create()
                .texOffs(0, 122).addBox(0F, -1.5F, -1.5F, 14F, 3F, 3F, new CubeDeformation(0F))
                .texOffs(241, 129).addBox(0F, -2.5F, -2F, 2F, 1F, 1F, new CubeDeformation(0F))
                .texOffs(0, 65).addBox(0F, 0.2F, 1.5F, 14F, 1F, 16F, new CubeDeformation(0F)),
                PartPose.offsetAndRotation(6F, -4F, -7F, 0F, 0F, 0F));
        PartDefinition d_wingForeR = d_wingArmR.addOrReplaceChild("wingForeR", CubeListBuilder.create()
                .texOffs(9, 129).addBox(0F, -1F, -1F, 16F, 2F, 2F, new CubeDeformation(0F))
                .texOffs(154, 0).addBox(0F, 0.2F, 1F, 16F, 1F, 22F, new CubeDeformation(0F)),
                PartPose.offsetAndRotation(14F, 0F, 0F, 0F, 0F, 0F));
        PartDefinition d_wingTipR = d_wingForeR.addOrReplaceChild("wingTipR", CubeListBuilder.create()
                .texOffs(83, 129).addBox(0F, -1F, -1F, 12F, 2F, 2F, new CubeDeformation(0F))
                .texOffs(130, 41).addBox(0F, 0.2F, 1F, 12F, 1F, 18F, new CubeDeformation(0F)),
                PartPose.offsetAndRotation(16F, 0F, 0F, 0F, 0F, 0F));
        PartDefinition d_wingArmL = d_body.addOrReplaceChild("wingArmL", CubeListBuilder.create()
                .texOffs(35, 122).addBox(-14F, -1.5F, -1.5F, 14F, 3F, 3F, new CubeDeformation(0F))
                .texOffs(248, 129).addBox(-14F, -2.5F, -2F, 2F, 1F, 1F, new CubeDeformation(0F))
                .texOffs(61, 65).addBox(-14F, 0.2F, 1.5F, 14F, 1F, 16F, new CubeDeformation(0F)),
                PartPose.offsetAndRotation(-6F, -4F, -7F, 0F, 0F, 0F));
        PartDefinition d_wingForeL = d_wingArmL.addOrReplaceChild("wingForeL", CubeListBuilder.create()
                .texOffs(46, 129).addBox(-16F, -1F, -1F, 16F, 2F, 2F, new CubeDeformation(0F))
                .texOffs(0, 41).addBox(-16F, 0.2F, 1F, 16F, 1F, 22F, new CubeDeformation(0F)),
                PartPose.offsetAndRotation(-14F, 0F, 0F, 0F, 0F, 0F));
        PartDefinition d_wingTipL = d_wingForeL.addOrReplaceChild("wingTipL", CubeListBuilder.create()
                .texOffs(112, 129).addBox(-12F, -1F, -1F, 12F, 2F, 2F, new CubeDeformation(0F))
                .texOffs(191, 41).addBox(-12F, 0.2F, 1F, 12F, 1F, 18F, new CubeDeformation(0F)),
                PartPose.offsetAndRotation(-16F, 0F, 0F, 0F, 0F, 0F));
        PartDefinition d_legFR = d_body.addOrReplaceChild("legFR", CubeListBuilder.create()
                .texOffs(27, 99).addBox(-3F, 0F, -3.5F, 6F, 5F, 7F, new CubeDeformation(0F)),
                PartPose.offsetAndRotation(6F, 4F, -9F, 0F, 0F, 0F));
        PartDefinition d_legFRLo = d_legFR.addOrReplaceChild("legFRLo", CubeListBuilder.create()
                .texOffs(141, 112).addBox(-2.5F, 0F, -2.5F, 5F, 4F, 5F, new CubeDeformation(0F)),
                PartPose.offsetAndRotation(0F, 5F, 0F, 0F, 0F, 0F));
        PartDefinition d_legFRFt = d_legFRLo.addOrReplaceChild("legFRFt", CubeListBuilder.create()
                .texOffs(0, 112).addBox(-3F, 0F, -6F, 6F, 1F, 8F, new CubeDeformation(0F))
                .texOffs(171, 129).addBox(-2.5F, -0.5F, -8F, 1F, 1F, 2F, new CubeDeformation(0F))
                .texOffs(164, 129).addBox(-0.5F, -0.5F, -8F, 1F, 1F, 2F, new CubeDeformation(0F))
                .texOffs(157, 129).addBox(1.5F, -0.5F, -8F, 1F, 1F, 2F, new CubeDeformation(0F)),
                PartPose.offsetAndRotation(0F, 4F, 0F, 0F, 0F, 0F));
        PartDefinition d_legFL = d_body.addOrReplaceChild("legFL", CubeListBuilder.create()
                .texOffs(54, 99).addBox(-3F, 0F, -3.5F, 6F, 5F, 7F, new CubeDeformation(0F)),
                PartPose.offsetAndRotation(-6F, 4F, -9F, 0F, 0F, 0F));
        PartDefinition d_legFLLo = d_legFL.addOrReplaceChild("legFLLo", CubeListBuilder.create()
                .texOffs(162, 112).addBox(-2.5F, 0F, -2.5F, 5F, 4F, 5F, new CubeDeformation(0F)),
                PartPose.offsetAndRotation(0F, 5F, 0F, 0F, 0F, 0F));
        PartDefinition d_legFLFt = d_legFLLo.addOrReplaceChild("legFLFt", CubeListBuilder.create()
                .texOffs(29, 112).addBox(-3F, 0F, -6F, 6F, 1F, 8F, new CubeDeformation(0F))
                .texOffs(192, 129).addBox(-2.5F, -0.5F, -8F, 1F, 1F, 2F, new CubeDeformation(0F))
                .texOffs(185, 129).addBox(-0.5F, -0.5F, -8F, 1F, 1F, 2F, new CubeDeformation(0F))
                .texOffs(178, 129).addBox(1.5F, -0.5F, -8F, 1F, 1F, 2F, new CubeDeformation(0F)),
                PartPose.offsetAndRotation(0F, 4F, 0F, 0F, 0F, 0F));
        PartDefinition d_legBR = d_body.addOrReplaceChild("legBR", CubeListBuilder.create()
                .texOffs(225, 65).addBox(-3.5F, -2F, -4F, 7F, 7F, 8F, new CubeDeformation(0F)),
                PartPose.offsetAndRotation(6F, 4F, 9F, 0F, 0F, 0F));
        PartDefinition d_legBRLo = d_legBR.addOrReplaceChild("legBRLo", CubeListBuilder.create()
                .texOffs(183, 112).addBox(-2.5F, 0F, -2.5F, 5F, 4F, 5F, new CubeDeformation(0F)),
                PartPose.offsetAndRotation(0F, 5F, 0F, 0F, 0F, 0F));
        PartDefinition d_legBRFt = d_legBRLo.addOrReplaceChild("legBRFt", CubeListBuilder.create()
                .texOffs(58, 112).addBox(-3F, 0F, -6F, 6F, 1F, 8F, new CubeDeformation(0F))
                .texOffs(213, 129).addBox(-2.5F, -0.5F, -8F, 1F, 1F, 2F, new CubeDeformation(0F))
                .texOffs(206, 129).addBox(-0.5F, -0.5F, -8F, 1F, 1F, 2F, new CubeDeformation(0F))
                .texOffs(199, 129).addBox(1.5F, -0.5F, -8F, 1F, 1F, 2F, new CubeDeformation(0F)),
                PartPose.offsetAndRotation(0F, 4F, 0F, 0F, 0F, 0F));
        PartDefinition d_legBL = d_body.addOrReplaceChild("legBL", CubeListBuilder.create()
                .texOffs(0, 83).addBox(-3.5F, -2F, -4F, 7F, 7F, 8F, new CubeDeformation(0F)),
                PartPose.offsetAndRotation(-6F, 4F, 9F, 0F, 0F, 0F));
        PartDefinition d_legBLLo = d_legBL.addOrReplaceChild("legBLLo", CubeListBuilder.create()
                .texOffs(204, 112).addBox(-2.5F, 0F, -2.5F, 5F, 4F, 5F, new CubeDeformation(0F)),
                PartPose.offsetAndRotation(0F, 5F, 0F, 0F, 0F, 0F));
        PartDefinition d_legBLFt = d_legBLLo.addOrReplaceChild("legBLFt", CubeListBuilder.create()
                .texOffs(87, 112).addBox(-3F, 0F, -6F, 6F, 1F, 8F, new CubeDeformation(0F))
                .texOffs(234, 129).addBox(-2.5F, -0.5F, -8F, 1F, 1F, 2F, new CubeDeformation(0F))
                .texOffs(227, 129).addBox(-0.5F, -0.5F, -8F, 1F, 1F, 2F, new CubeDeformation(0F))
                .texOffs(220, 129).addBox(1.5F, -0.5F, -8F, 1F, 1F, 2F, new CubeDeformation(0F)),
                PartPose.offsetAndRotation(0F, 4F, 0F, 0F, 0F, 0F));
        return LayerDefinition.create(mesh, 256, 256);
    }

    @Override
    public void setupAnim(AncientDragonEntity entity, float limbSwing, float limbSwingAmount, float ageInTicks,
                          float netHeadYaw, float headPitch) {
        float partial = ageInTicks - entity.tickCount;
        float fly = entity.getFlyAnim(partial);
        float t = ageInTicks;
        float swing = Mth.cos(limbSwing * 0.55F) * limbSwingAmount;
        float breath = entity.getBreathAnim(partial);

        // cuello y cabeza
        float yaw = netHeadYaw * ((float) Math.PI / 180F);
        float pitch = headPitch * ((float) Math.PI / 180F);
        float sway = Mth.sin(t * 0.05F) * 0.05F;
        this.neck1.yRot = yaw * 0.3F + sway;
        this.neck2.yRot = yaw * 0.3F + sway;
        this.neck3.yRot = yaw * 0.3F + sway;
        this.neck1.xRot = -0.55F - breath * 0.25F - fly * 0.2F;
        this.neck2.xRot = 0.15F - breath * 0.1F + fly * 0.1F;
        this.neck3.xRot = 0.25F;
        this.head.xRot = 0.35F + pitch * 0.5F - breath * 0.2F;
        this.jaw.xRot = 0.05F + breath * 0.75F + (Mth.sin(t * 0.1F) * 0.02F);
        this.hornR.xRot = 0.55F;
        this.hornL.xRot = 0.55F;

        // cola
        this.tail1.yRot = Mth.sin(t * 0.09F - 0F) * 0.14F + swing * 0.1F * (0 % 2 == 0 ? 1F : -1F);
        this.tail1.xRot = -0.05F + fly * 0.04F;
        this.tail2.yRot = Mth.sin(t * 0.09F - 0.6F) * 0.17F + swing * 0.1F * (1 % 2 == 0 ? 1F : -1F);
        this.tail2.xRot = 0.03F + fly * 0.04F;
        this.tail3.yRot = Mth.sin(t * 0.09F - 1.2F) * 0.2F + swing * 0.1F * (2 % 2 == 0 ? 1F : -1F);
        this.tail3.xRot = 0.03F + fly * 0.04F;
        this.tail4.yRot = Mth.sin(t * 0.09F - 1.8F) * 0.23F + swing * 0.1F * (3 % 2 == 0 ? 1F : -1F);
        this.tail4.xRot = 0.03F + fly * 0.04F;
        this.tail5.yRot = Mth.sin(t * 0.09F - 2.4F) * 0.26F + swing * 0.1F * (4 % 2 == 0 ? 1F : -1F);
        this.tail5.xRot = 0.03F + fly * 0.04F;
        this.tail6.yRot = Mth.sin(t * 0.09F - 3F) * 0.29F + swing * 0.1F * (5 % 2 == 0 ? 1F : -1F);
        this.tail6.xRot = 0.03F + fly * 0.04F;

        // alas: plegadas en tierra, abiertas y batiendo al volar
        float flap = Mth.sin(t * 0.32F);
        float flap2 = Mth.sin(t * 0.32F - 0.6F);
        float flap3 = Mth.sin(t * 0.32F - 1.2F);
        float idle = Mth.sin(t * 0.04F) * 0.03F;
        float armZ = Mth.lerp(fly, 0.75F + idle, 0.1F + flap * 0.6F);
        float armY = Mth.lerp(fly, 0.95F, 0.15F);
        float foreZ = Mth.lerp(fly, -0.1F, flap2 * 0.5F);
        float foreY = Mth.lerp(fly, 1.45F, 0.4F);
        float tipZ = Mth.lerp(fly, 0.05F, flap3 * 0.45F);
        float tipY = Mth.lerp(fly, 0.9F, 0.3F);
        this.wingArmR.zRot = -armZ;
        this.wingArmR.yRot = -armY;
        this.wingForeR.zRot = -foreZ;
        this.wingForeR.yRot = -foreY;
        this.wingTipR.zRot = -tipZ;
        this.wingTipR.yRot = -tipY;
        this.wingArmL.zRot = armZ;
        this.wingArmL.yRot = armY;
        this.wingForeL.zRot = foreZ;
        this.wingForeL.yRot = foreY;
        this.wingTipL.zRot = tipZ;
        this.wingTipL.yRot = tipY;

        // patas: caminan en tierra y se recogen en vuelo
        float tuck = fly * 0.9F;
        this.legFR.xRot = Mth.lerp(fly, swing * 0.9F, 0.9F);
        this.legFL.xRot = Mth.lerp(fly, -swing * 0.9F, 0.9F);
        this.legBR.xRot = Mth.lerp(fly, -swing * 0.9F, -0.7F);
        this.legBL.xRot = Mth.lerp(fly, swing * 0.9F, -0.7F);
        this.legFRLo.xRot = Math.max(0F, -swing) * 0.6F + tuck * 0.6F;
        this.legFLLo.xRot = Math.max(0F, swing) * 0.6F + tuck * 0.6F;
        this.legBRLo.xRot = Math.max(0F, swing) * 0.6F + tuck * 0.9F;
        this.legBLLo.xRot = Math.max(0F, -swing) * 0.6F + tuck * 0.9F;
        this.legFRFt.xRot = -tuck * 0.5F;
        this.legFLFt.xRot = -tuck * 0.5F;
        this.legBRFt.xRot = -tuck * 0.5F;
        this.legBLFt.xRot = -tuck * 0.5F;

        this.saddle.visible = entity.isSaddled();

        // el cuerpo sube y baja al respirar o volar
        this.body.y = 10F + Mth.sin(t * 0.07F) * 0.25F + fly * flap * 0.6F;
        this.body.xRot = fly * (-0.1F);
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay,
                               float red, float green, float blue, float alpha) {
        this.root.render(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }
}
