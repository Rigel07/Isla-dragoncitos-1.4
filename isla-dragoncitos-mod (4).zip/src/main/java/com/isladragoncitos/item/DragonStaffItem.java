package com.isladragoncitos.item;

import com.isladragoncitos.entity.AncientDragonEntity;
import java.util.List;
import java.util.Optional;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;

/** Baculo del Dragon: guarda a tu dragon antiguo dentro y lo libera donde quieras. */
public class DragonStaffItem extends Item {
    private static final String KEY = "StoredDragon";

    public DragonStaffItem(Properties properties) {
        super(properties);
    }

    public static boolean isFilled(ItemStack stack) {
        return stack.hasTag() && stack.getTag().contains(KEY);
    }

    /** Atrapa al dragon dentro del baculo (clic derecho sobre tu dragon con el baculo vacio). */
    public static InteractionResult capture(AncientDragonEntity dragon, Player player, ItemStack stack) {
        Level level = dragon.level();
        if (level.isClientSide) {
            return InteractionResult.SUCCESS;
        }
        if (isFilled(stack)) {
            player.displayClientMessage(Component.literal("El báculo ya guarda un dragón."), true);
            return InteractionResult.FAIL;
        }
        dragon.ejectPassengers();
        CompoundTag data = new CompoundTag();
        if (!dragon.save(data)) {
            return InteractionResult.FAIL;
        }
        stack.getOrCreateTag().put(KEY, data);
        stack.getOrCreateTag().putInt("DragonType", dragon.getDragonType());
        stack.getOrCreateTag().putInt("DragonFood", dragon.getFood());
        if (level instanceof ServerLevel serverLevel) {
            serverLevel.sendParticles(ParticleTypes.PORTAL, dragon.getX(), dragon.getY() + dragon.getBbHeight() * 0.5D,
                    dragon.getZ(), 60, dragon.getBbWidth() * 0.4D, dragon.getBbHeight() * 0.4D, dragon.getBbWidth() * 0.4D, 0.5D);
        }
        level.playSound(null, dragon.blockPosition(), SoundEvents.ENDERMAN_TELEPORT, SoundSource.PLAYERS, 1.0F, 0.8F);
        dragon.discard();
        player.displayClientMessage(Component.literal("Tu dragón descansa dentro del báculo."), true);
        return InteractionResult.SUCCESS;
    }

    /** Libera al dragon en el bloque pulsado. */
    @Override
    public InteractionResult useOn(UseOnContext context) {
        ItemStack stack = context.getItemInHand();
        if (!isFilled(stack)) {
            return InteractionResult.PASS;
        }
        Level level = context.getLevel();
        if (level.isClientSide) {
            return InteractionResult.SUCCESS;
        }
        CompoundTag data = stack.getTag().getCompound(KEY);
        BlockPos pos = context.getClickedPos().relative(context.getClickedFace());
        Optional<Entity> created = EntityType.create(data, level);
        if (created.isEmpty()) {
            return InteractionResult.FAIL;
        }
        Entity entity = created.get();
        entity.moveTo(pos.getX() + 0.5D, pos.getY(), pos.getZ() + 0.5D, context.getRotation(), 0.0F);
        level.addFreshEntity(entity);
        stack.getTag().remove(KEY);
        stack.getTag().remove("DragonType");
        stack.getTag().remove("DragonFood");
        if (level instanceof ServerLevel serverLevel) {
            serverLevel.sendParticles(ParticleTypes.PORTAL, pos.getX() + 0.5D, pos.getY() + 1.0D, pos.getZ() + 0.5D,
                    60, 1.0D, 1.0D, 1.0D, 0.5D);
        }
        level.playSound(null, pos, SoundEvents.ENDERMAN_TELEPORT, SoundSource.PLAYERS, 1.0F, 1.2F);
        Player player = context.getPlayer();
        if (player != null && entity instanceof AncientDragonEntity dragon) {
            com.isladragoncitos.system.DraconicData.setActiveDragon(player, dragon);
        }
        return InteractionResult.SUCCESS;
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return isFilled(stack);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        if (isFilled(stack)) {
            tooltip.add(Component.translatable("tooltip.isladragoncitos.staff.full").withStyle(ChatFormatting.LIGHT_PURPLE));
            tooltip.add(Component.translatable("tooltip.isladragoncitos.staff.release").withStyle(ChatFormatting.DARK_GRAY));
        } else {
            tooltip.add(Component.translatable("tooltip.isladragoncitos.staff.empty").withStyle(ChatFormatting.GRAY));
        }
    }
}
