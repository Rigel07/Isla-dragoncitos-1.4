# La Isla de los Dragoncitos (Forge 1.20.1)

Mod para Minecraft Forge 1.20.1 (Forge 47.2.0, Java 17).

## Qué añade
- **Islas flotantes** que aparecen en distintos lugares del mundo, casi siempre junto a un **río**: de la isla cae una **cascada** hasta el río y una **enredadera gigante** (raíces de manglar y musgo con lianas) sube desde el suelo hasta el borde. Se trepa por las lianas.
- Naturaleza preciosa: cerezos, robles, azaleas, flores, un **lago**, playa, lianas con bayas luminosas colgando por debajo, y una **plaza antigua** con pilares y arcos en ruinas y un **santuario** de piedra.
- **Dragoncitos** (rosa, verde, azul y rojo): no crecen, son cariñosos y vuelan con aleteos cortos.
  - Dales **carne** (vacuno, cerdo, cordero, pollo, conejo; cruda o cocinada) para domesticarlos (50 % de probabilidad por intento).
  - **Clic derecho** sobre uno tuyo: alterna entre *seguirte* y *quedarse quieto*. Con carne se cura.
- **Cofres** (en el santuario y junto a los pilares) con **escamas** de dragón verde, azul, roja y rosa y **manuscritos** con historias épicas de los antiguos dragones (son libros que se leen normal).
- **Estatua del Dragón** en el centro de cada isla:
  - Clic derecho en una estatua sin dueño: le pones **nombre** a la isla y pasa a ser **tuya**.
  - Solo tú y los jugadores a los que des permiso podéis **entrar, construir y destruir** (también protege contra explosiones y cubos de agua/lava). Quien no tenga permiso es devuelto al pie de la enredadera.
  - Desde la estatua puedes **teletransportarte a las otras islas** cuya estatua ya hayas usado.
  - El dueño gestiona los **permisos** (dar / quitar) desde el mismo menú de la estatua.

## Novedades 1.1.0
- **Islas todas distintas**: 6 estilos (Primavera, Nieve, Volcánica, Cristal, Jungla, Oasis) con su propio suelo, árboles, flora, piedra y ruinas; el bioma favorece uno pero puede salir cualquiera.
- **Tamaños de 11 a 46 de radio** (diminutas a gigantes), forma irregular/alargada, grosor y relieve variables.
- **Estructuras variables**: santuario, **torre en ruinas** (2 pisos con escalera y 2 cofres) o **nido de dragoncitos**; 5-12 pilares; lagos de distinto tamaño, **estanques** extra en islas grandes, **cráter de lava** en las volcánicas y **islotes flotantes** (algunos con cofre).
- Los dragoncitos de cada isla tienden al color de su estilo.
- **Escamas con utilidad**: clic derecho (rosa cura, verde hace florecer piedra/tierra, azul aliento de mar, roja protege del fuego); sobre tu dragoncito le cambian el color; los dragoncitos domados sueltan escamas de su color de vez en cuando.
- **Amuletos** (oro + escama): 2 efectos permanentes en el inventario. **Brújula de Dragón** (brújula + 4 escamas): señala la isla más cercana. **Bloques de escamas** decorativos que brillan.
- Las islas ya generadas en mundos antiguos se conservan tal cual; lo nuevo vale para islas nuevas.

## Novedades 1.2.0 (Dragones Antiguos)
- **Islas**: ahora hay islas simples (sin adornos), islas enormes (hasta radio ~64) con **Gran Templo** o **Ciudadela** (con altar y, a veces, un **huevo de dragón antiguo**), más islotes y estanques en las grandes.
- **Huevo de Dragón Antiguo** (fuego, hielo o tormenta): escondido en el suelo del mapa (muy raro, en un hueco con musgo) y en altares de islas grandes. Colócalo y eclosiona en ~5 min (más rápido junto a fuego/lava) en un dragón domado.
- **Dragón Antiguo**: modelo propio épico, ojos que brillan. Crece **según la comida** (carne; manzanas doradas) hasta un tamaño gigante. Sigue, se queda o deambula 32 bloques; te defiende con **fuego, hielo o rayo**. Los dragoncitos sienten adoración por él.
- **Montadragones** (silla + 4 escamas): clic derecho sobre tu dragón para montarlo. Mira arriba y avanza para despegar; mira abajo para aterrizar.
- **Báculo del Dragón**: guarda a tu dragón (clic derecho sobre él) y libéralo en un bloque.
- **/dragon**: menú clicable. Seguir, quedarse, deambular aquí, **explorar** (vuela o camina según estuviera), **isla cercana** (detecta islas aún no descubiertas), **ir <isla>** (vuelo automático a una isla con nombre), **apodar <nombre>** (renombra la isla donde estás), estado y mejoras. Si mueves el dragón con las teclas, recuperas el control (la cámara no cuenta).
- **Puntos draconianos**: +10 por cada isla de dragoncitos descubierta. Mejoras: fuerza (máx 200, 1 pto/nivel), velocidad (máx 20, 5), vida (máx 400, 0,5), escamas protectoras (máx 100, 1 pto cada una; cada escama reduce un golpe a la mitad y se gasta) y **vida compartida** (100 puntos exactos): vuestra vida se suma y es la misma para los dos; un corazón del color del dragón con el número sustituye la barra. Si uno muere, el otro también (tú reapareces, el dragón no).
- **Marca del Jinete**: al eclosionar tu primer dragón duplica tus ventajas (puntos, efectos de amuletos y escamas, vida aportada por el dragón).
- **Dragón del Agua** (el más raro y fuerte): su huevo está en el fondo de los océanos profundos. Nace con estadísticas más altas, **vuela bajo el agua a gran velocidad** y da **respiración acuática y visión nocturna** al jinete mientras está en el agua; respira bajo el agua y escupe chorros que empujan.
- La **Marca del Jinete** dura mientras viva el dragón que la despertó y duplica todas las ventajas, actuales y futuras (incluidas las mejoras del dragón y el desgaste de escamas).
- 18 **logros** nuevos.

## Novedades 1.4.0
- **La Crónica de los Jinetes del Alba**: una civilización de jinetes de dragones que desapareció. Ocho capítulos (de "El Primer Huevo" a la "Carta de Naru") en libros que aparecen en los cofres de las islas y de las ruinas, y en atriles dentro de los santuarios, torres, templos y ciudadelas.
- **Ruinas por el mundo**: Atalaya del Jinete (torre en ruinas), Cementerio de Dragones (esqueleto colosal y campamento de su jinete), Círculo del Alba (ofrendas de escamas y cofre escondido bajo el altar) y Pilar de las Profundidades (ruinas de prismarina en el océano profundo).
- **En las islas nuevas**: fósiles de dragón y atriles con la crónica.
- **Montura fija**: el Montadragones se queda puesto en el dragón (se ve la silla). Con la silla puesta, clic derecho con la mano vacía para montar; agachado + clic derecho con el Montadragones para quitarla.
- **Vuelo montado**: espacio para despegar y subir; avanzar mirando abajo desciende.
- **Navegación**: al explorar o ir a una isla el dragón esquiva bloques (sube, baja o rodea) y se libera si se atasca.
- **Cámara**: el jinete va sentado por encima del modelo, así que se ve bien por muy grande que sea el dragón.
- **Seguirte sin agobiar**: el dragón te acompaña en un anillo a cierta distancia, ya no se pega a tu cabeza.
- **Huevos**: iconos propios (ya no sale el bloque negro y violeta).
- **Vida compartida**: corazón grande y centrado, entre la armadura y la barra de experiencia, del color de tu dragón y con borde dorado; el número baja con el daño que reciba cualquiera de los dos.
- **Edulnari**: al morir, tu dragón deja una esencia con sus niveles y habilidades (sin tamaño ni escamas). Clic derecho con ella sobre un huevo de dragón antes de que eclosione y el nuevo dragón, del tipo del huevo, nace con esas mejoras.
- 3 logros nuevos (ruinas, primera página, cronista).

## Novedades 1.5.0
- **Nuevo diseño 3D de los dragones antiguos**: cada tipo (fuego, hielo, tormenta y agua) usa su propio modelo épico de unos 600-780 cubos, con textura propia y **capa que brilla en la oscuridad** (lava, rayos, cristales, bioluminiscencia y ojos).
- **Animaciones**: reposo, caminar, volar, planear y aliento; el dragón del agua además **nada** (`swim` / `swim_idle`) cuando está bajo el agua. La cabeza sigue hacia donde mira.
- Los modelos se dibujan con **GeckoLib** (el .jar de GeckoLib 4.4.9 o superior para 1.20.1 es necesario; se descarga solo al compilar y hay que tenerlo en la carpeta `mods` para jugar).
- Los archivos están en `assets/isladragoncitos/geo/entity`, `animations/entity` y `textures/entity` (`<tipo>_dragon.*`). El tamaño base se ajusta con `MODEL_SCALE` en `AncientDragonRenderer`.
- Los dragoncitos pequeños no cambian.

## Novedades 1.6.0 (menú del dragón)
- **Menú gráfico del dragón**: pulsa **G** (se puede cambiar en Controles) o escribe `/dragon`. Ya no hace falta usar comandos para mejorar a tu dragón.
- Colores y adornos según el elemento (fuego, hielo, tormenta o agua) y **vista previa del dragón** que te mira a ti.
- Pestaña **Mejoras**: barras de fuerza, velocidad, vida y escamas con botones **+1 / +10 / Máx** (se desactivan si no te llegan los puntos; el cursor te dice el coste) y botón para unir las vidas. El resultado se muestra en el propio menú.
- Pestaña **Órdenes**: seguir, quedarse, deambular, explorar, isla cercana y parar (la orden actual aparece resaltada).
- Pestaña **Viajes**: lista de tus islas, un clic y el dragón te lleva.
- El menú se actualiza solo al comprar o dar una orden. Los comandos siguen funcionando; el antiguo menú de texto ahora es `/dragon texto`.

## Comandos
- `/isladragoncitos release` (operadores): libera la isla reclamada más cercana (a menos de 24 bloques).
- `/locate structure isladragoncitos:isla` para encontrar una isla.
- Los operadores (nivel 2) no tienen restricciones de protección.

## Ajustar la frecuencia
`src/main/resources/data/isladragoncitos/worldgen/structure_set/islas.json`: `spacing` (distancia media entre intentos, en chunks) y `separation`.
Dentro de `IslaStructure.java`, `NO_RIVER_CHANCE` controla cuántas islas aparecen lejos de un río.

## Compilar con GitHub (sin instalar nada)
1. Sube a un repositorio **este .zip tal cual** (sin descomprimir) y el archivo `.github/workflows/build.yml`
   (créalo con *Add file → Create new file* escribiendo la ruta `.github/workflows/build.yml`).
2. GitHub descomprime el zip, compila y deja el `.jar` en **Actions → último run → Artifacts → mod-jar**.
3. Copia el `.jar` a la carpeta `mods` de Forge 1.20.1.

Compilar en local: `gradle build` (Gradle 8.1.1, JDK 17). El jar queda en `build/libs/`.
