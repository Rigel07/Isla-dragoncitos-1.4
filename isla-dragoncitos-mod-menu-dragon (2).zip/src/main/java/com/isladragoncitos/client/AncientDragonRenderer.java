package com.isladragoncitos.client;

import com.isladragoncitos.entity.AncientDragonEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import software.bernie.geckolib.cache.object.BakedGeoModel;
import software.bernie.geckolib.renderer.GeoEntityRenderer;
import software.bernie.geckolib.renderer.layer.AutoGlowingGeoLayer;

/** Dibuja al dragon antiguo con el modelo 3D de GeckoLib; lava, rayos, cristales y ojos brillan en la oscuridad. */
public class AncientDragonRenderer extends GeoEntityRenderer<AncientDragonEntity> {
    /**
     * Los modelos nuevos miden unos 15 bloques de largo a escala 1. Este factor los lleva al mismo tamano
     * que el dragon anterior para que la hitbox, la montura y la camara sigan encajando. Subelo o bajalo
     * si los quieres mas grandes o mas pequenos.
     */
    public static final float MODEL_SCALE = 0.45F;

    public AncientDragonRenderer(EntityRendererProvider.Context context) {
        super(context, new AncientDragonGeoModel());
        // usa X_dragon_glowmask.png junto a la textura
        this.addRenderLayer(new AutoGlowingGeoLayer<>(this));
    }

    @Override
    public void scaleModelForRender(float widthScale, float heightScale, PoseStack poseStack, AncientDragonEntity dragon,
                                    BakedGeoModel model, boolean isReRender, float partialTick, int packedLight,
                                    int packedOverlay) {
        float scale = dragon.getVisualScale() * MODEL_SCALE;
        this.shadowRadius = 1.6F * scale;
        super.scaleModelForRender(widthScale * scale, heightScale * scale, poseStack, dragon, model, isReRender,
                partialTick, packedLight, packedOverlay);
    }
}
