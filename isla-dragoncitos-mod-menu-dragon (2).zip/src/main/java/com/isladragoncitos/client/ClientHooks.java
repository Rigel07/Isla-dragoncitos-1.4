package com.isladragoncitos.client;

import com.isladragoncitos.network.DragonMenuInfo;
import com.isladragoncitos.network.StatueInfo;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;

/** Puntos de entrada del cliente (se llaman desde los paquetes via DistExecutor). */
public final class ClientHooks {
    private ClientHooks() {}

    public static void openNameScreen(BlockPos pos) {
        Minecraft.getInstance().setScreen(new NameIslandScreen(pos));
    }

    public static void openStatueScreen(StatueInfo info) {
        Minecraft.getInstance().setScreen(new StatueScreen(info));
    }

    /** Abre el menu del dragon, o solo actualiza sus datos si ya esta abierto. */
    public static void openDragonScreen(DragonMenuInfo info) {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.screen instanceof DragonScreen screen) {
            screen.update(info);
        } else {
            minecraft.setScreen(new DragonScreen(info));
        }
    }
}
